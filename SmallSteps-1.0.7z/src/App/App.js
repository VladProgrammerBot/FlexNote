import Accordion from '../Accordion'
import './App.scss'

export default () => {
	return (
		<div className='app'>
			<Accordion />
		</div>
	)
}
