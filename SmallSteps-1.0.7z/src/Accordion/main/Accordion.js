import { useState, useEffect } from "react";
import AconItem from "../AconItem"

export default () => {
	const [roadmaps, setRoadmaps] = useState();
	const [indexNow, setIndexNow] = useState(18);

	useEffect(() => {
		fetch('./roadmaps.json')
			.then(answer => answer.json())
			.then(data => setRoadmaps(data))
	}, [])

	const togleCheckbox = (value, id) => {
		const setChildrensActive = (roadmap) => {
			return roadmap.map((child) => {
				return {
					...child,
					isChecked: value,
					childrens: setChildrensActive(child.childrens)
				}
			})
		}

		const hasActiveChildrens = (roadmap) => {
			let hasInclude = false

			const checkInclude = (roadmap) => {
				roadmap.map((child) => {
					if (child.isChecked && child.id !== id || child.id === id && value) {
						hasInclude = true
					}
					if (child.isChecked && child.id !== id && value === !child.isChecked) {
						hasInclude = false
					}
					checkInclude(child.childrens)
				})
			}

			checkInclude(roadmap)

			return hasInclude
		}

		const newRoadmap = (roadmaps) => {
			return roadmaps.map((roadmap) => {
				if (roadmap.id === id) {
					return {
						...roadmap,
						isChecked: value,
						isSubChecked: hasActiveChildrens(roadmap.childrens),
						childrens: setChildrensActive(roadmap.childrens)
					}
				}

				return {
					...roadmap,
					isSubChecked: hasActiveChildrens(roadmap.childrens),
					childrens: newRoadmap(roadmap.childrens)
				}
			})
		}

		setRoadmaps(newRoadmap(roadmaps))
	}

	const addFolder = (folderId, value) => {
		const newRoadmap = (roadmaps) => {
			return roadmaps.map((roadmap) => {
				if (roadmap.id === folderId) {
					return {
						...roadmap,
						childrens: [
							...roadmap.childrens,
							{
								id: indexNow,
								isChecked: false,
								isSubChecked: false,
								name: value,
								childrens: []
							}
						]
					}
				}
				return {
					...roadmap,
					childrens: newRoadmap(roadmap.childrens)
				}
			})
		}

		setRoadmaps(newRoadmap(roadmaps))
		setIndexNow(indexNow + 1)
	}

	const removeFolder = (folderId) => {
		const newRoadmap = (roadmaps) => {
			return roadmaps.filter((roadmap) => {
				return roadmap.id !== folderId
			}).map((roadmap) => {
				return {
					...roadmap,
					childrens: newRoadmap(roadmap.childrens)
				}
			})
		}

		setRoadmaps(newRoadmap(roadmaps))
	}

	const toggleMainFolder = (folder) => {
		const newRoadmap = (roadmaps) => {
			return roadmaps.map((roadmap) => {
				if (roadmap.id === folder.id) {
					return {
						...roadmap,
						isMain: !folder.isMain
					}
				}
				return {
					...roadmap,
					childrens: newRoadmap(roadmap.childrens)
				}
			})
		}

		setRoadmaps(newRoadmap(roadmaps))
	}

	return (
		<div>
			{roadmaps?.map((item) => {
				return (
					<AconItem
						key={item.id}
						roadmap={item}
						togleCheckbox={togleCheckbox}
						addFolder={addFolder}
						removeFolder={removeFolder}
						toggleMainFolder={toggleMainFolder}
					/>
				)
			})}
		</div>
	)
}