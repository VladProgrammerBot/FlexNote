import AconItem from './'
import AconItemForm from '../AconItemForm';
import './AconItem.scss'

import { FaAngleDown, FaAngleUp, FaLessThanEqual } from "react-icons/fa";
import { MdOutlineRadioButtonUnchecked, MdOutlineRadioButtonChecked, MdDeleteOutline } from "react-icons/md";
import { IoMdAdd } from "react-icons/io";
import { GoCheckCircle } from "react-icons/go";
import { FaStar } from "react-icons/fa";

import { useEffect, useState, useMemo } from 'react'

export default ({
	roadmap,
	togleCheckbox,
	addFolder,
	removeFolder,
	toggleMainFolder
}) => {
	const [isOpen, setIsOpen] = useState(false)
	const [isFormOpen, setIsFormOpen] = useState(false)

	useEffect(() => {
		if (!isOpen) {
			setIsFormOpen()
		}
	}, [isOpen])

	const ShowFolderForm = (id) => {
		setIsOpen(true)
		setIsFormOpen(id)
	}

	const AddNewFolder = (value) => {
		addFolder(isFormOpen, value)
		setIsFormOpen()
	}

	return (
		<div className='acc-item'>
			<div className={`AccItemTitle ${roadmap.isChecked && 'checked'} ${roadmap.isMain && 'main'}`}>
				<div className='toggleBtn' onClick={() => togleCheckbox(!roadmap.isChecked, roadmap.id)}>
					{roadmap.isChecked ? <GoCheckCircle /> :
						roadmap.isSubChecked ? <MdOutlineRadioButtonChecked /> :
							<MdOutlineRadioButtonUnchecked />}
				</div>
				<div className='title'>
					{roadmap.name}
				</div>
				<div className='d-flex'>
					<div className='toggleBtn' onClick={() => ShowFolderForm(roadmap.id)}>
						<IoMdAdd />
					</div>
					<div className='toggleBtn delete' onClick={() => removeFolder(roadmap.id)}>
						<MdDeleteOutline />
					</div>
					<div className='toggleBtn star' onClick={() => toggleMainFolder(roadmap)}>
						<FaStar color={`${roadmap.isMain ? 'white' : 'black'}`} />
					</div>
					<div className='toggleBtn' onClick={() => setIsOpen(!isOpen)}>
						{roadmap.childrens.length ? (isOpen ? <FaAngleUp /> : <FaAngleDown />) : null}
					</div>
				</div>
			</div>
			{isFormOpen && isOpen && <AconItemForm AddNewFolder={AddNewFolder} />}
			{roadmap.childrens.length > 0 && roadmap.childrens && isOpen && (
				<div>
					{roadmap.childrens.map((folder) => {
						return (
							<AconItem
								key={folder.id}
								roadmap={folder}
								togleCheckbox={togleCheckbox}
								addFolder={addFolder}
								removeFolder={removeFolder}
								toggleMainFolder={toggleMainFolder}
							/>
						)
					})}
				</div>
			)}
		</div>
	)
}
